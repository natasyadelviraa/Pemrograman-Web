<?php
$tinggi = 5; // Tinggi segitiga

for ($i = $tinggi; $i >= 1; $i--) {
    // Menambahkan spasi di depan bintang
    for ($j = $tinggi; $j > $i; $j--) {
        echo "&nbsp;";
    }
    
    // Mencetak bintang
    for ($k = 1; $k <= (2 * $i - 1); $k++) {
        echo "*";
    }
    
    echo "<br>";
}
?>
