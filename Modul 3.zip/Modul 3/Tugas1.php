<?php

// Trait
trait Deskripsi {
    public function getDeskripsi() {
        return "Ini adalah contoh program menggunakan OOP di PHP.";
    }
}

// Abstract Class
abstract class Program {
    abstract public function tampilkanInfo();
}

// Class utama
class ContohProgram extends Program {
    use Deskripsi;

    private $judul;
    private $versi;

    public function __construct($judul, $versi) {
        $this->judul = $judul;
        $this->versi = $versi;
    }

    public function tampilkanInfo() {
        echo "Judul: " . $this->judul . "<br>";
        echo "Versi: " . $this->versi . "<br>";
    }
}

// Inisialisasi objek
$program = new ContohProgram("Pemrograman Website", "1.0");
$program->tampilkanInfo();
echo $program->getDeskripsi();

?>
